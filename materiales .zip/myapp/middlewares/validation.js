let { body } = require('express-validator');

const validation = [ 

    //Aca van las validaciones del form

]

module.exports = validation;