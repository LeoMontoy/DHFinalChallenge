const APIcontroller = {

    //Aca va la logica//
    
    }
    
module.exports = APIcontroller