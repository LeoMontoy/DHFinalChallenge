let { validationResult } = require('express-validator');

const Controller = {

    index: (req, res) => {

        res.render('index')

    }


    }

module.exports = Controller