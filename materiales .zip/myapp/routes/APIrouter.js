const express = require('express');
const router = express.Router();
const Controller = require('../controllers/APIcontroller')


//Aca van las rutas de tu API



module.exports = router;
